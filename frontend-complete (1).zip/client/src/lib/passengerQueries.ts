import { supabase } from '@/integrations/supabase/client';

export interface PassengerWithDetails {
  id: string;
  name: string;
  passport_number: string | null;
  national_id: string | null;
  date_of_birth: string | null;
  nationality: string | null;
  email: string | null;
  phone: string | null;
  photo_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface Restriction {
  id: string;
  passenger_id: string;
  reason: string;
  restriction_type: string;
  severity: string;
  start_date: string;
  end_date: string | null;
  status: string;
  created_by: string | null;
  approved_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface Incident {
  id: string;
  passenger_id: string;
  incident_type: string;
  description: string;
  severity: string;
  location: string | null;
  reported_by: string | null;
  created_at: string;
}

export interface PassengerCheckResult {
  passenger: PassengerWithDetails;
  activeRestrictions: Restriction[];
  incidents: Incident[];
  hasActiveRestriction: boolean;
}

/**
 * Search for a passenger by passport number or national ID
 */
export async function findPassenger(query: string): Promise<PassengerWithDetails | null> {
  const trimmedQuery = query.trim();
  
  // Try to find by passport number or national ID
  const { data, error } = await supabase
    .from('passengers')
    .select('*')
    .or(`passport_number.eq.${trimmedQuery},national_id.eq.${trimmedQuery}`)
    .single();

  if (error) {
    console.error('[PassengerQueries] Error finding passenger:', error);
    return null;
  }

  return data;
}

/**
 * Get active restrictions for a passenger
 * Active = approved restrictions that haven't expired yet
 */
export async function getPassengerRestrictions(passengerId: string): Promise<Restriction[]> {
  const now = new Date().toISOString();
  
  const { data, error } = await supabase
    .from('restrictions')
    .select('*')
    .eq('passenger_id', passengerId)
    .eq('status', 'approved')
    .or(`end_date.is.null,end_date.gte.${now}`)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('[PassengerQueries] Error fetching restrictions:', error);
    return [];
  }

  return data || [];
}

/**
 * Get incidents for a passenger
 */
export async function getPassengerIncidents(passengerId: string): Promise<Incident[]> {
  const { data, error } = await supabase
    .from('incidents')
    .select('*')
    .eq('passenger_id', passengerId)
    .order('created_at', { ascending: false })
    .limit(10);

  if (error) {
    console.error('[PassengerQueries] Error fetching incidents:', error);
    return [];
  }

  return data || [];
}

/**
 * Comprehensive passenger check - returns passenger with restrictions and incidents
 */
export async function checkPassenger(query: string): Promise<PassengerCheckResult | null> {
  // Find the passenger
  const passenger = await findPassenger(query);
  
  if (!passenger) {
    return null;
  }

  // Fetch restrictions and incidents in parallel
  const [restrictions, incidents] = await Promise.all([
    getPassengerRestrictions(passenger.id),
    getPassengerIncidents(passenger.id),
  ]);

  return {
    passenger,
    activeRestrictions: restrictions,
    incidents,
    hasActiveRestriction: restrictions.length > 0,
  };
}
