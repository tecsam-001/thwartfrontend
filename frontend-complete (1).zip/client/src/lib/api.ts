import axios, { AxiosError, AxiosRequestConfig } from 'axios';

// Get API base URL from environment variable
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'https://thwart-api-app-esf2eeb8efh9gqb4.centralus-01.azurewebsites.net';

// Create axios instance
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Token management (in-memory for security, localStorage as fallback for dev)
let authToken: string | null = null;

export const setAuthToken = (token: string | null) => {
  authToken = token;
  if (token) {
    // Dev-only: persist to localStorage for convenience
    if (import.meta.env.DEV) {
      localStorage.setItem('thwart_token', token);
    }
  } else {
    if (import.meta.env.DEV) {
      localStorage.removeItem('thwart_token');
    }
  }
};

export const getAuthToken = (): string | null => {
  if (authToken) return authToken;
  // Dev-only: retrieve from localStorage
  if (import.meta.env.DEV) {
    const stored = localStorage.getItem('thwart_token');
    if (stored) {
      authToken = stored;
      return stored;
    }
  }
  return null;
};

// Request interceptor to add auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = getAuthToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      console.log('[API] Request to:', config.url, 'with token:', token.substring(0, 20) + '...');
    } else {
      console.log('[API] Request to:', config.url, 'WITHOUT token');
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    console.error('[API] Response error:', {
      status: error.response?.status,
      url: error.config?.url,
      data: error.response?.data
    });
    
    if (error.response?.status === 401) {
      console.log('[API] 401 Unauthorized - clearing token and redirecting to login');
      // Token expired or invalid
      setAuthToken(null);
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Retry wrapper for network requests
const withRetry = async <T>(
  fn: () => Promise<T>,
  retries = 1
): Promise<T> => {
  try {
    return await fn();
  } catch (error) {
    if (retries > 0 && axios.isAxiosError(error) && !error.response) {
      // Network error, retry
      await new Promise(resolve => setTimeout(resolve, 1000));
      return withRetry(fn, retries - 1);
    }
    throw error;
  }
};

// API Methods
export const api = {
  // Auth
  login: (username: string, password: string) =>
    withRetry(() => {
      console.log('[API] Calling login endpoint...');
      return apiClient.post('/auth/login', { username, password });
    }),

  // Check passenger - maps backend response to frontend structure
  check: async (query: string) => {
    const response = await withRetry(() =>
      apiClient.get('/check', { params: { q: query } })
    );
    
    // Map backend response to frontend CheckResult structure
    if (response.data.success && response.data.passenger) {
      const backendData = response.data;
      const passenger = backendData.passenger;
      
      response.data = {
        passenger: {
          id: passenger.passenger_id,
          passport_number: backendData.primary_document?.doc_number,
          id_number: backendData.primary_document?.doc_number,
          full_name: `${passenger.first_name || ''} ${passenger.last_name || ''}`.trim(),
          date_of_birth: passenger.date_of_birth,
          nationality: passenger.nationality,
          is_restricted: backendData.status === 'restricted',
          restriction_reason: backendData.restriction?.reason,
          restriction_end_date: backendData.restriction?.end_date,
          created_at: backendData.timestamp,
        },
        incidents: backendData.history || [],
        active_restriction: backendData.restriction,
      };
    }
    
    return response;
  },

  // Create passenger
  createPassenger: (data: any) =>
    withRetry(() =>
      apiClient.post('/passenger', data)
    ),

  // Report incident
  reportIncident: (data: any) =>
    withRetry(() =>
      apiClient.post('/incident/report', data)
    ),

  // Get restrictions (admin)
  getRestrictions: async () => {
    const response = await withRetry(() =>
      apiClient.get('/admin/restrictions')
    );
    
    // Map backend response - backend returns { success, count, records }
    if (response.data.records) {
      response.data = response.data.records.map((r: any) => ({
        id: r.restriction_id,
        passenger_id: r.passenger_id,
        passenger_name: r.passenger_name,
        reason: r.reason,
        severity: r.severity,
        start_date: r.start_date,
        end_date: r.end_date,
        status: r.admin_status?.toLowerCase() || r.status?.toLowerCase(),
        restriction_status: r.status?.toLowerCase(),
        created_by: r.issued_by,
        approved_by: r.approved_by,
        created_at: r.created_at,
        approved_at: r.approved_at,
      }));
    }
    
    return response;
  },

  // Approve restriction
  approveRestriction: (id: string) =>
    withRetry(() =>
      apiClient.post(`/admin/restrictions/${id}/approve`)
    ),

  // Decline restriction
  declineRestriction: (id: string) =>
    withRetry(() =>
      apiClient.post(`/admin/restrictions/${id}/decline`)
    ),

  // Update restriction status (deprecated - use approve/decline instead)
  updateRestriction: (id: string, status: string) =>
    withRetry(() =>
      apiClient.patch(`/admin/restrictions/${id}`, { admin_status: status.toUpperCase() })
    ),

  // Auto-approve restrictions
  autoApprove: () =>
    withRetry(() =>
      apiClient.post('/admin/auto-approve-now')
    ),

  // Get incidents/history
  getIncidents: (params?: any) =>
    withRetry(() =>
      apiClient.get('/history', { params })
    ),

  // Appeals
  submitAppeal: (data: { restriction_id: string; passenger_id: string; reason: string }) =>
    withRetry(() =>
      apiClient.post('/appeal', data)
    ),

  getPassengerAppeals: (passengerId: string) =>
    withRetry(() =>
      apiClient.get(`/appeal/${passengerId}`)
    ),

  // Dashboard statistics
  getDashboardStats: () =>
    withRetry(() =>
      apiClient.get('/stats')
    ),
};

export default apiClient;
