import React from 'react';
import { Badge } from '@/components/ui/badge';
import { ShieldAlert, ShieldCheck } from 'lucide-react';

interface StatusBadgeProps {
  isRestricted: boolean;
  size?: 'sm' | 'lg';
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ isRestricted, size = 'sm' }) => {
  if (isRestricted) {
    return (
      <Badge 
        variant="destructive" 
        className={`${size === 'lg' ? 'text-lg px-6 py-3' : ''} font-bold`}
      >
        <ShieldAlert className={`${size === 'lg' ? 'h-6 w-6' : 'h-4 w-4'} mr-2`} />
        RESTRICTED — DO NOT SERVE
      </Badge>
    );
  }

  return (
    <Badge 
      className={`${size === 'lg' ? 'text-lg px-6 py-3' : ''} bg-success text-success-foreground hover:bg-success/90 font-bold`}
    >
      <ShieldCheck className={`${size === 'lg' ? 'h-6 w-6' : 'h-4 w-4'} mr-2`} />
      CLEAR — SERVE
    </Badge>
  );
};

export default StatusBadge;
