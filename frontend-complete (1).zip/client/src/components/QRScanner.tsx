import React, { useEffect, useRef } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface QRScannerProps {
  onScan: (value: string) => void;
  onClose: () => void;
}

const QRScanner: React.FC<QRScannerProps> = ({ onScan, onClose }) => {
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const isScanning = useRef(false);

  useEffect(() => {
    const startScanner = async () => {
      try {
        const html5QrCode = new Html5Qrcode('qr-reader');
        scannerRef.current = html5QrCode;

        await html5QrCode.start(
          { facingMode: 'environment' },
          {
            fps: 10,
            qrbox: { width: 250, height: 250 },
          },
          (decodedText) => {
            if (!isScanning.current) {
              isScanning.current = true;
              onScan(decodedText);
              stopScanner();
            }
          },
          (errorMessage) => {
            // Silent error - scanning in progress
          }
        );
      } catch (err: any) {
        toast({
          title: 'Scanner error',
          description: err.message || 'Unable to access camera',
          variant: 'destructive',
        });
        onClose();
      }
    };

    const stopScanner = async () => {
      if (scannerRef.current && scannerRef.current.isScanning) {
        try {
          await scannerRef.current.stop();
        } catch (err) {
          console.error('Error stopping scanner:', err);
        }
      }
    };

    startScanner();

    return () => {
      stopScanner();
    };
  }, [onScan, onClose]);

  return (
    <div className="relative">
      <div className="flex justify-end mb-2">
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      <div id="qr-reader" className="w-full"></div>
      <p className="text-sm text-muted-foreground text-center mt-4">
        Position the QR code or barcode within the frame
      </p>
    </div>
  );
};

export default QRScanner;
