import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Upload, FileText, CheckCircle, XCircle, Loader2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

interface JobStatus {
  job_id: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  total: number;
  processed: number;
  succeeded: number;
  failed: number;
  created_at: string;
  updated_at: string;
}

interface JobError {
  row: number;
  record: any;
  reason: string;
}

export const BulkImportTab: React.FC = () => {
  const { user } = useAuth();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [currentJobId, setCurrentJobId] = useState<string | null>(null);
  const [jobStatus, setJobStatus] = useState<JobStatus | null>(null);
  const [errors, setErrors] = useState<JobError[]>([]);
  const [isDragging, setIsDragging] = useState(false);

  // Poll for job status updates
  useEffect(() => {
    if (!currentJobId || !jobStatus) return;

    if (jobStatus.status === 'running' || jobStatus.status === 'pending') {
      const interval = setInterval(async () => {
        await fetchJobStatus(currentJobId);
      }, 2000); // Poll every 2 seconds

      return () => clearInterval(interval);
    }
  }, [currentJobId, jobStatus]);

  const getAuthToken = async (): Promise<string> => {
    const { data: { session } } = await import('@/integrations/supabase/client').then(m => m.supabase.auth.getSession());
    if (!session?.access_token) {
      throw new Error('No authentication token available');
    }
    return session.access_token;
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      validateAndSetFile(file);
    }
  };

  const validateAndSetFile = (file: File) => {
    // Validate file type
    const validTypes = ['text/csv', 'application/json', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel'];
    const validExtensions = ['.csv', '.json', '.xlsx', '.xls'];
    const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf('.'));

    if (!validTypes.includes(file.type) && !validExtensions.includes(fileExtension)) {
      toast.error('Invalid file type. Please upload CSV, JSON, or XLSX files only.');
      return;
    }

    // Validate file size (10MB limit)
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
      toast.error('File too large. Maximum size is 10MB.');
      return;
    }

    setSelectedFile(file);
    setErrors([]);
    setJobStatus(null);
    toast.success(`File selected: ${file.name}`);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file) {
      validateAndSetFile(file);
    }
  };

  const uploadFile = async () => {
    if (!selectedFile) {
      toast.error('Please select a file first');
      return;
    }

    setIsUploading(true);
    setErrors([]);

    try {
      const token = await getAuthToken();
      const formData = new FormData();
      formData.append('file', selectedFile);

      const response = await fetch('/api/bulk-import/file', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Upload failed: ${response.statusText}`);
      }

      const data = await response.json();
      setCurrentJobId(data.job_id);
      setJobStatus(data);
      
      toast.success(`Upload started! Job ID: ${data.job_id.substring(0, 8)}...`);
    } catch (error: any) {
      console.error('[BulkImport] Upload error:', error);
      toast.error(error.message || 'Upload failed');
    } finally {
      setIsUploading(false);
    }
  };

  const fetchJobStatus = async (jobId: string) => {
    try {
      const token = await getAuthToken();
      const response = await fetch(`/api/bulk-import/status/${jobId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch job status');
      }

      const data = await response.json();
      setJobStatus(data);

      // Fetch errors if job is completed or failed
      if ((data.status === 'completed' || data.status === 'failed') && data.failed > 0) {
        await fetchJobErrors(jobId);
      }
    } catch (error: any) {
      console.error('[BulkImport] Status fetch error:', error);
    }
  };

  const fetchJobErrors = async (jobId: string) => {
    try {
      const token = await getAuthToken();
      const response = await fetch(`/api/bulk-import/errors/${jobId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch errors');
      }

      const data = await response.json();
      setErrors(data.errors || []);
    } catch (error: any) {
      console.error('[BulkImport] Error fetch error:', error);
    }
  };

  const getProgressPercentage = () => {
    if (!jobStatus || jobStatus.total === 0) return 0;
    return Math.round((jobStatus.processed / jobStatus.total) * 100);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge variant="default" className="bg-green-600"><CheckCircle className="h-3 w-3 mr-1" />Completed</Badge>;
      case 'failed':
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Failed</Badge>;
      case 'running':
        return <Badge variant="secondary"><Loader2 className="h-3 w-3 mr-1 animate-spin" />Running</Badge>;
      case 'pending':
        return <Badge variant="outline"><AlertCircle className="h-3 w-3 mr-1" />Pending</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Upload Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Bulk Import Historical Incidents
          </CardTitle>
          <CardDescription>
            Upload CSV, XLSX, or JSON files with historical incident data. Maximum 10MB, 10,000 records per file.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Drag and Drop Zone */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              isDragging 
                ? 'border-primary bg-primary/5' 
                : 'border-muted-foreground/25 hover:border-primary/50'
            }`}
          >
            <Upload className={`h-12 w-12 mx-auto mb-4 ${isDragging ? 'text-primary' : 'text-muted-foreground'}`} />
            <p className="text-sm font-medium mb-2">
              {selectedFile ? selectedFile.name : 'Drag and drop your file here'}
            </p>
            <p className="text-xs text-muted-foreground mb-4">
              or click to browse
            </p>
            <Input
              id="file-upload"
              type="file"
              accept=".csv,.json,.xlsx,.xls"
              onChange={handleFileChange}
              className="hidden"
              data-testid="input-bulk-import-file"
            />
            <Label htmlFor="file-upload">
              <Button variant="outline" size="sm" asChild>
                <span>
                  <FileText className="h-4 w-4 mr-2" />
                  Select File
                </span>
              </Button>
            </Label>
          </div>

          {/* Selected File Info */}
          {selectedFile && (
            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm font-medium">{selectedFile.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {(selectedFile.size / 1024).toFixed(2)} KB
                  </p>
                </div>
              </div>
              <Button
                onClick={uploadFile}
                disabled={isUploading}
                data-testid="button-start-upload"
              >
                {isUploading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    Start Upload
                  </>
                )}
              </Button>
            </div>
          )}

          {/* Security Notice */}
          <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
            <p className="text-sm text-blue-900 dark:text-blue-100">
              <strong>Security:</strong> Rate limited to 10 uploads per 15 minutes. Files are processed asynchronously with full authentication and validation.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Job Status Card */}
      {jobStatus && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">
                Job Status: {currentJobId?.substring(0, 8)}...
              </CardTitle>
              {getStatusBadge(jobStatus.status)}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>{jobStatus.processed} / {jobStatus.total}</span>
              </div>
              <Progress value={getProgressPercentage()} className="h-2" />
            </div>

            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-2xl font-bold">{jobStatus.total}</p>
                <p className="text-xs text-muted-foreground">Total Records</p>
              </div>
              <div className="p-3 bg-green-50 dark:bg-green-950/20 rounded-lg">
                <p className="text-2xl font-bold text-green-600 dark:text-green-400">{jobStatus.succeeded}</p>
                <p className="text-xs text-muted-foreground">Succeeded</p>
              </div>
              <div className="p-3 bg-red-50 dark:bg-red-950/20 rounded-lg">
                <p className="text-2xl font-bold text-red-600 dark:text-red-400">{jobStatus.failed}</p>
                <p className="text-xs text-muted-foreground">Failed</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Errors Table */}
      {errors.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <XCircle className="h-5 w-5 text-destructive" />
              Import Errors ({errors.length})
            </CardTitle>
            <CardDescription>
              Review records that failed to import
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="border rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-20">Row</TableHead>
                    <TableHead>Reason</TableHead>
                    <TableHead>Record Preview</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {errors.slice(0, 100).map((error, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-mono text-sm">{error.row}</TableCell>
                      <TableCell className="text-sm">
                        <pre className="whitespace-pre-wrap break-words text-xs">
                          {error.reason}
                        </pre>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground font-mono max-w-md">
                        <pre className="whitespace-pre-wrap break-words">
                          {error.record._truncated 
                            ? `${error.record._preview}\n(Original size: ${error.record._original_size} bytes)`
                            : JSON.stringify(error.record, null, 2).substring(0, 200)
                          }
                        </pre>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            {errors.length > 100 && (
              <p className="text-sm text-muted-foreground mt-4 text-center">
                Showing first 100 errors of {errors.length} total
              </p>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};
