import React, { createContext, useContext, useState, useEffect } from 'react';
import { User as SupabaseUser, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

interface Profile {
  id: string;
  username: string;
  full_name: string | null;
  role: string;
}

interface AuthContextType {
  user: SupabaseUser | null;
  profile: Profile | null;
  session: Session | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isProfileLoading: boolean;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, username: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<SupabaseUser | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isProfileLoading, setIsProfileLoading] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  const fetchProfile = async (userId: string) => {
    setIsProfileLoading(true);
    try {
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();
      
      if (profileError) {
        console.error('[AuthContext] Profile query error:', profileError);
        setProfile(null);
      } else if (profileData) {
        console.log('[AuthContext] ✓ Profile loaded:', profileData.username);
        setProfile(profileData);
      } else {
        console.warn('[AuthContext] No profile found for user:', userId);
        setProfile(null);
      }

      const { data: adminRole, error: roleError } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', userId)
        .eq('role', 'admin')
        .maybeSingle();
      
      if (roleError) {
        console.error('[AuthContext] Role query error:', roleError);
        setIsAdmin(false);
      } else if (adminRole) {
        console.log('[AuthContext] ✓ Admin role confirmed');
        setIsAdmin(true);
      } else {
        console.log('[AuthContext] ✗ No admin role found');
        setIsAdmin(false);
      }
    } catch (error) {
      console.error('[AuthContext] Error fetching profile:', error);
      setProfile(null);
      setIsAdmin(false);
    } finally {
      setIsProfileLoading(false);
    }
  };

  useEffect(() => {
    console.log('[AuthContext] Setting up auth listener...');

    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      console.log('[AuthContext] Initial session:', session ? 'EXISTS' : 'NONE');
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        fetchProfile(session.user.id);
      }
      
      setIsLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log('[AuthContext] Auth state changed:', event, session ? 'HAS_SESSION' : 'NO_SESSION');
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          setTimeout(() => {
            fetchProfile(session.user.id);
          }, 0);
        } else {
          setProfile(null);
          setIsAdmin(false);
        }
      }
    );

    return () => {
      console.log('[AuthContext] Cleaning up auth listener');
      subscription.unsubscribe();
    };
  }, []);

  const login = async (email: string, password: string) => {
    console.log('[AuthContext] Login attempt for:', email);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      console.log('[AuthContext] Login successful:', data.user?.email);
      
      toast({
        title: 'Login successful',
        description: `Welcome back!`,
      });
    } catch (error: any) {
      console.error('[AuthContext] Login failed:', error);
      
      toast({
        title: 'Login failed',
        description: error.message || 'Invalid credentials',
        variant: 'destructive',
      });
      throw error;
    }
  };

  const signUp = async (email: string, password: string, username: string) => {
    console.log('[AuthContext] Sign up attempt for:', email);
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            username,
          },
          emailRedirectTo: `${window.location.origin}/dashboard`,
        },
      });

      if (error) throw error;

      console.log('[AuthContext] Sign up successful');
      
      toast({
        title: 'Account created',
        description: 'Welcome to THWART!',
      });
    } catch (error: any) {
      console.error('[AuthContext] Sign up failed:', error);
      
      toast({
        title: 'Sign up failed',
        description: error.message || 'Could not create account',
        variant: 'destructive',
      });
      throw error;
    }
  };

  const logout = async () => {
    console.log('[AuthContext] Logout initiated');
    try {
      await supabase.auth.signOut();
      setUser(null);
      setProfile(null);
      setSession(null);
      setIsAdmin(false);
      
      toast({
        title: 'Logged out',
        description: 'You have been logged out successfully',
      });
    } catch (error) {
      console.error('[AuthContext] Logout error:', error);
    }
  };

  const isAuthenticated = !!session;
  
  console.log('[AuthContext] Current state:', {
    user: user?.email || 'null',
    profile: profile?.username || 'null',
    isAuthenticated,
    isLoading,
  });

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        session,
        isAuthenticated,
        isLoading,
        isProfileLoading,
        isAdmin,
        login,
        signUp,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
