export interface User {
  id: string;
  username: string;
  role: 'staff' | 'admin' | 'client';
  email?: string;
}

export interface Passenger {
  id: string;
  passport_number?: string;
  id_number?: string;
  full_name: string;
  date_of_birth?: string;
  nationality?: string;
  photo_url?: string;
  is_restricted: boolean;
  restriction_reason?: string;
  restriction_end_date?: string;
  created_at: string;
}

export interface Incident {
  id: string;
  passenger_id: string;
  incident_type: string;
  severity: number;
  description: string;
  location?: string;
  reported_by: string;
  reported_at: string;
  ai_suggestion?: string;
}

export interface Restriction {
  id: string;
  passenger_id: string;
  passenger_name?: string;
  reason: string;
  severity: number;
  start_date: string;
  end_date?: string;
  status: 'pending' | 'approved' | 'rejected' | 'active' | 'expired' | 'declined';
  restriction_status?: string;
  created_by: string;
  approved_by?: string;
  approved_at?: string;
  created_at: string;
}

export interface Appeal {
  appeal_id: string;
  restriction_id: string;
  passenger_id: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
  reviewed_at?: string;
  reviewed_by?: string;
}

export interface CheckResult {
  passenger: Passenger;
  incidents: Incident[];
  active_restriction?: Restriction;
}

export interface LoginResponse {
  token: string;
  user: User;
}
