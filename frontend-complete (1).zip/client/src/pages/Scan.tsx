import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ScanLine, Keyboard, Camera, FileText, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { checkPassenger, PassengerCheckResult } from '@/lib/passengerQueries';
import QRScanner from '@/components/QRScanner';
import { useAuth } from '@/contexts/AuthContext';
import StatusBadge from '@/components/StatusBadge';

const Scan: React.FC = () => {
  const navigate = useNavigate();
  const { isAdmin } = useAuth();
  const [manualId, setManualId] = useState('');
  const [manualName, setManualName] = useState('');
  const [manualAddress, setManualAddress] = useState('');
  const [manualDob, setManualDob] = useState('');
  const [manualNationality, setManualNationality] = useState('');
  const [isChecking, setIsChecking] = useState(false);
  const [checkResult, setCheckResult] = useState<PassengerCheckResult | null>(null);
  const [showScanner, setShowScanner] = useState(false);

  const handleCheck = async (query: string) => {
    if (!query.trim()) return;

    setIsChecking(true);
    try {
      const result = await checkPassenger(query.trim());
      
      if (!result) {
        toast({
          title: 'Person not found',
          description: 'No record found with that ID or passport number',
          variant: 'destructive',
        });
        setCheckResult(null);
        return;
      }

      setCheckResult(result);
      
      // Alert if patron has active restrictions
      if (result.hasActiveRestriction) {
        toast({
          title: 'Active Restriction – DO NOT SERVE',
          description: 'This person has active alcohol service restrictions',
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'No Active Restriction – SERVE',
          description: 'This person is eligible for alcohol service',
        });
      }
    } catch (error: any) {
      console.error('[Scan] Error checking passenger:', error);
      toast({
        title: 'Check failed',
        description: 'Unable to check passenger. Please try again.',
        variant: 'destructive',
      });
      setCheckResult(null);
    } finally {
      setIsChecking(false);
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleCheck(manualId);
  };

  const handleScanResult = (scannedValue: string) => {
    setShowScanner(false);
    handleCheck(scannedValue);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Serve Check</h1>
        <p className="text-muted-foreground">
          Scan or manually enter ID to check alcohol service eligibility
        </p>
      </div>

      {/* Status Legend */}
      <Card>
        <CardHeader>
          <CardTitle>Status</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-4">
          <StatusBadge isRestricted={false} />
          <StatusBadge isRestricted={true} />
        </CardContent>
      </Card>

      <Tabs defaultValue="manual" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="manual">
            <Keyboard className="h-4 w-4 mr-2" />
            Manual Entry
          </TabsTrigger>
          <TabsTrigger value="scan">
            <Camera className="h-4 w-4 mr-2" />
            QR/Barcode Scan
          </TabsTrigger>
        </TabsList>

        <TabsContent value="manual">
          <Card>
            <CardHeader>
              <CardTitle>Manual ID Entry</CardTitle>
              <CardDescription>
                Enter passport or ID number manually
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleManualSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="manual-id">Passport / ID Number</Label>
                  <Input
                    id="manual-id"
                    placeholder="e.g., P1234567 or ID98765"
                    value={manualId}
                    onChange={(e) => setManualId(e.target.value)}
                    autoFocus
                    data-testid="input-manual-id"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="manual-name">Name</Label>
                  <Input
                    id="manual-name"
                    placeholder="e.g., John Doe"
                    value={manualName}
                    onChange={(e) => setManualName(e.target.value)}
                    data-testid="input-manual-name"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="manual-address">Address</Label>
                  <Input
                    id="manual-address"
                    placeholder="e.g., 123 Main Street, City"
                    value={manualAddress}
                    onChange={(e) => setManualAddress(e.target.value)}
                    data-testid="input-manual-address"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="manual-dob">Date of Birth</Label>
                  <Input
                    id="manual-dob"
                    type="date"
                    value={manualDob}
                    onChange={(e) => setManualDob(e.target.value)}
                    data-testid="input-manual-dob"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="manual-nationality">Nationality</Label>
                  <Input
                    id="manual-nationality"
                    placeholder="e.g., American"
                    value={manualNationality}
                    onChange={(e) => setManualNationality(e.target.value)}
                    data-testid="input-manual-nationality"
                  />
                </div>

                <Button type="submit" className="w-full" disabled={isChecking}>
                  <ScanLine className="h-4 w-4 mr-2" />
                  {isChecking ? 'Checking...' : 'Serve Check'}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="scan">
          <Card>
            <CardHeader>
              <CardTitle>QR/Barcode Scanner</CardTitle>
              <CardDescription>
                Allow camera access to scan passenger documents
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!showScanner ? (
                <Button 
                  onClick={() => setShowScanner(true)} 
                  className="w-full"
                >
                  <Camera className="h-4 w-4 mr-2" />
                  Start Scanner
                </Button>
              ) : (
                <QRScanner 
                  onScan={handleScanResult}
                  onClose={() => setShowScanner(false)}
                />
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Check Result Display */}
      {checkResult && (
        <>
          {/* Alert Banner for Active Restrictions */}
          {checkResult.hasActiveRestriction && (
            <Alert variant="destructive" className="border-2" data-testid="alert-active-restriction">
              <AlertTriangle className="h-5 w-5" />
              <AlertDescription className="font-semibold text-lg text-destructive">
                Active Restriction – DO NOT SERVE
              </AlertDescription>
            </Alert>
          )}

          {!checkResult.hasActiveRestriction && (
            <Alert className="border-2 border-green-500 bg-green-50 dark:bg-green-950" data-testid="alert-no-restriction">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <AlertDescription className="font-semibold text-green-700 dark:text-green-400">
                No Active Restriction – SERVE
              </AlertDescription>
            </Alert>
          )}

          <Card data-testid="card-passenger-info">
            <CardHeader>
              <CardTitle className="flex items-center justify-between gap-2">
                Patron Information
                {checkResult.hasActiveRestriction ? (
                  <Badge variant="destructive" data-testid="badge-restricted">
                    <XCircle className="h-3 w-3 mr-1" />
                    DO NOT SERVE
                  </Badge>
                ) : (
                  <Badge className="bg-green-600 dark:bg-green-700" data-testid="badge-clear">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    SERVE
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {!isAdmin ? (
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Full Name</Label>
                    <p className="text-lg font-semibold" data-testid="text-passenger-name">
                      {checkResult.passenger.name}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>Passport Number</Label>
                    <p className="text-lg" data-testid="text-passport-number">
                      {checkResult.passenger.passport_number || 'N/A'}
                    </p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-sm text-muted-foreground text-center mt-6">
                      Limited vendor view - Status only
                    </p>
                  </div>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Full Name</Label>
                    <p className="text-lg font-semibold" data-testid="text-passenger-name">
                      {checkResult.passenger.name}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>Passport Number</Label>
                    <p className="text-lg" data-testid="text-passport-number">
                      {checkResult.passenger.passport_number || 'N/A'}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>National ID</Label>
                    <p className="text-lg" data-testid="text-national-id">
                      {checkResult.passenger.national_id || 'N/A'}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>Nationality</Label>
                    <p className="text-lg" data-testid="text-nationality">
                      {checkResult.passenger.nationality || 'N/A'}
                    </p>
                  </div>
                </div>
              )}

              {/* Active Restrictions Details - ADMIN ONLY */}
              {isAdmin && checkResult.hasActiveRestriction && (
                <div className="space-y-4">
                  <h3 className="font-bold text-lg text-destructive flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5" />
                    Active Restrictions ({checkResult.activeRestrictions.length})
                  </h3>
                  {checkResult.activeRestrictions.map((restriction, index) => (
                    <div 
                      key={restriction.id} 
                      className="bg-muted border rounded-lg p-4 space-y-3"
                      data-testid={`restriction-${index}`}
                    >
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <Badge variant="destructive" data-testid={`badge-severity-${index}`}>
                          {restriction.severity?.toUpperCase() || 'UNKNOWN'} Severity
                        </Badge>
                        <Badge variant="outline" data-testid={`badge-type-${index}`}>
                          {restriction.restriction_type || 'General'}
                        </Badge>
                      </div>
                      <div>
                        <p className="font-semibold text-destructive mb-1">Reason:</p>
                        <p className="text-sm" data-testid={`text-reason-${index}`}>{restriction.reason}</p>
                      </div>
                      <div className="mt-3 p-3 bg-muted/50 rounded-md border-l-4 border-primary">
                        <p className="text-sm font-medium mb-1">To Appeal This Restriction:</p>
                        <p className="text-xs text-muted-foreground">
                          The passenger will receive a restriction notice letter via email with detailed appeal instructions and contact information.
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Incidents - ADMIN ONLY */}
              {isAdmin && checkResult.incidents && checkResult.incidents.length > 0 && (
                <div className="space-y-3">
                  <h3 className="font-bold text-lg">
                    Recent Incidents ({checkResult.incidents.length})
                  </h3>
                  <div className="space-y-2">
                    {checkResult.incidents.slice(0, 5).map((incident, index) => (
                      <div 
                        key={incident.id} 
                        className="bg-muted p-3 rounded-lg text-sm border"
                        data-testid={`incident-${index}`}
                      >
                        <div className="flex items-center justify-between gap-2 flex-wrap mb-2">
                          <p className="font-semibold">{incident.incident_type}</p>
                          <Badge 
                            variant={incident.severity === 'high' || incident.severity === 'critical' ? 'destructive' : 'secondary'}
                            data-testid={`badge-incident-severity-${index}`}
                          >
                            {incident.severity}
                          </Badge>
                        </div>
                        <p className="text-muted-foreground mb-1">{incident.description}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(incident.created_at).toLocaleDateString()} at {new Date(incident.created_at).toLocaleTimeString()}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
};

export default Scan;
