import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ArrowLeft, UserPlus } from 'lucide-react';
import { toast } from 'sonner';
import thwartLogo from '@/assets/thwart-logo-transparent.png';

const AdminLogin: React.FC = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loginAttempted, setLoginAttempted] = useState(false);
  const { login, logout, isAdmin, isAuthenticated, isLoading: authLoading, isProfileLoading } = useAuth();

  // Watch for admin role after login attempt
  useEffect(() => {
    // Wait for auth to settle AND profile/role to load
    if (loginAttempted && isAuthenticated && !authLoading && !isProfileLoading) {
      if (isAdmin) {
        // User is admin - grant access
        toast.success('Admin access granted');
        setLoginAttempted(false); // Clear flag after success
        navigate('/admin-panel');
      } else {
        // User is not admin - deny access and logout
        toast.error('Access denied: Admin privileges required');
        setLoginAttempted(false); // Clear flag after failure
        setIsLoading(false);
        logout();
      }
    }
  }, [loginAttempted, isAuthenticated, authLoading, isProfileLoading, isAdmin, navigate, logout]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setLoginAttempted(true);

    try {
      // Login with email and password
      await login(email, password);
      // The useEffect above will handle role verification and navigation
    } catch (error) {
      // Error toast handled in AuthContext
      console.error('Admin login error:', error);
      setLoginAttempted(false);
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted px-4">
      <div className="absolute top-4 left-4">
        <Button
          variant="ghost"
          onClick={() => navigate('/login')}
          className="flex items-center gap-2"
          data-testid="button-back-to-login"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Login
        </Button>
      </div>
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <img 
              src={thwartLogo} 
              alt="THWART Logo" 
              className="h-32 w-auto [animation:none]"
              style={{
                filter: 'brightness(0) saturate(100%) invert(45%) sepia(85%) saturate(2000%) hue-rotate(190deg) brightness(100%) contrast(95%)',
                animation: 'none'
              }}
            />
          </div>
          <CardTitle className="text-2xl">Admin Access</CardTitle>
          <CardDescription>
            Login with your admin credentials
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="admin-email" className="block text-center">Email</Label>
              <Input
                id="admin-email"
                type="email"
                placeholder="Enter admin email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoFocus
                className="text-center"
                data-testid="input-admin-email"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="admin-password" className="block text-center">Password</Label>
              <Input
                id="admin-password"
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                className="text-center"
                data-testid="input-admin-password"
              />
            </div>
            <Button
              type="submit"
              className="w-full"
              disabled={isLoading}
              data-testid="button-admin-login"
            >
              {isLoading ? 'Logging in...' : 'Access Admin Panel'}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex justify-center pb-6 pt-0">
          <p className="text-xs text-muted-foreground text-center">
            First time?{' '}
            <Link 
              to="/admin-setup" 
              className="text-primary hover:underline inline-flex items-center gap-1"
              data-testid="link-admin-setup"
            >
              <UserPlus className="h-3 w-3" />
              Create admin account
            </Link>
          </p>
        </CardFooter>
      </Card>
    </div>
  );
};

export default AdminLogin;
