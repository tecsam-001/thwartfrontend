import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { UserPlus, Upload } from 'lucide-react';

// Changed: Added national_id as REQUIRED primary identifier instead of using email
const passengerSchema = z.object({
  national_id: z.string().min(1, 'National ID / Passenger ID is required').max(50),
  first_name: z.string().min(1, 'First name is required').max(100),
  last_name: z.string().min(1, 'Last name is required').max(100),
  date_of_birth: z.string().min(1, 'Date of birth is required'),
  nationality: z.string().min(1, 'Nationality is required').max(100),
  passport_number: z.string().optional(),
  email: z.string().email().optional().or(z.literal('')),
  phone: z.string().optional(),
});

type PassengerFormData = z.infer<typeof passengerSchema>;

const CreatePassenger: React.FC = () => {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  // Changed: Add state to track if passenger exists and is being looked up
  const [isLookingUp, setIsLookingUp] = useState(false);
  const [existingPassenger, setExistingPassenger] = useState<any>(null);
  const [lastLookupId, setLastLookupId] = useState<string>(''); // Track last lookup to avoid duplicate toasts

  const form = useForm<PassengerFormData>({
    resolver: zodResolver(passengerSchema),
    defaultValues: {
      national_id: '',
      first_name: '',
      last_name: '',
      date_of_birth: '',
      nationality: '',
      passport_number: '',
      email: '',
      phone: '',
    },
  });

  // Changed: Function to lookup passenger by national_id with debouncing
  const handleNationalIdLookup = React.useCallback(async (nationalId: string) => {
    // Normalize: trim and uppercase
    const normalizedId = nationalId.trim().toUpperCase();
    
    // Don't lookup if empty or too short
    if (!normalizedId || normalizedId.length < 3) {
      setExistingPassenger(null);
      setLastLookupId('');
      return;
    }

    // Don't lookup again if we just looked up this ID
    if (normalizedId === lastLookupId) {
      return;
    }

    setIsLookingUp(true);
    setLastLookupId(normalizedId);
    
    try {
      const { data, error } = await supabase
        .from('passengers')
        .select('*')
        .eq('national_id', normalizedId)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        // Passenger exists - populate form with their data
        setExistingPassenger(data);
        const [firstName, ...lastNameParts] = data.name.split(' ');
        form.setValue('first_name', firstName || '');
        form.setValue('last_name', lastNameParts.join(' ') || '');
        form.setValue('date_of_birth', data.date_of_birth || '');
        form.setValue('nationality', data.nationality || '');
        form.setValue('passport_number', data.passport_number || '');
        form.setValue('email', data.email || '');
        form.setValue('phone', data.phone || '');
        
        // Set photo preview if exists
        if (data.photo_url) {
          setPhotoPreview(data.photo_url);
        }

        toast({
          title: 'Passenger Found',
          description: `Existing passenger found: ${data.name}. You can update their information below.`,
        });
      } else {
        // New passenger - clear form except national_id
        setExistingPassenger(null);
        setPhotoPreview(null);
        toast({
          title: 'New Passenger',
          description: 'No existing passenger found with this ID. Please fill in their details.',
        });
      }
    } catch (error: any) {
      console.error('[CreatePassenger] Lookup error:', error);
      toast({
        title: 'Lookup Error',
        description: error.message || 'Failed to lookup passenger',
        variant: 'destructive',
      });
    } finally {
      setIsLookingUp(false);
    }
  }, [lastLookupId, form, toast]);

  // Debounced lookup effect
  React.useEffect(() => {
    const nationalId = form.watch('national_id');
    const timer = setTimeout(() => {
      handleNationalIdLookup(nationalId);
    }, 500); // 500ms debounce

    return () => clearTimeout(timer);
  }, [form.watch('national_id'), handleNationalIdLookup]);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Changed: Updated to handle both creating new passengers and updating existing ones using national_id
  const onSubmit = async (data: PassengerFormData) => {
    setIsSubmitting(true);
    try {
      let photoUrl = existingPassenger?.photo_url || null;

      // Upload photo if provided
      if (photoFile) {
        const fileExt = photoFile.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
        const filePath = `${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('passenger-photos')
          .upload(filePath, photoFile);

        if (uploadError) {
          throw uploadError;
        }

        const { data: urlData } = supabase.storage
          .from('passenger-photos')
          .getPublicUrl(filePath);

        photoUrl = urlData.publicUrl;
      }

      // Changed: Normalize national_id before saving (trim and uppercase)
      const passengerData = {
        national_id: data.national_id.trim().toUpperCase(),
        name: `${data.first_name} ${data.last_name}`,
        date_of_birth: data.date_of_birth,
        nationality: data.nationality,
        passport_number: data.passport_number || null,
        email: data.email || null,
        phone: data.phone || null,
        photo_url: photoUrl,
      };

      if (existingPassenger) {
        // Update existing passenger
        const { data: passenger, error } = await supabase
          .from('passengers')
          .update(passengerData)
          .eq('id', existingPassenger.id)
          .select()
          .single();

        if (error) throw error;

        toast({
          title: 'Success',
          description: `Passenger updated successfully. National ID: ${passenger.national_id}`,
        });
      } else {
        // Create new passenger
        const { data: passenger, error } = await supabase
          .from('passengers')
          .insert(passengerData)
          .select()
          .single();

        if (error) throw error;

        toast({
          title: 'Success',
          description: `Passenger created successfully. National ID: ${passenger.national_id}`,
        });
      }
      
      // Reset form
      form.reset();
      setPhotoFile(null);
      setPhotoPreview(null);
      setExistingPassenger(null);
      
      // Navigate to dashboard
      setTimeout(() => {
        navigate('/dashboard');
      }, 1500);
    } catch (error: any) {
      console.error('[CreatePassenger] Error:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to save passenger',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Add New Passenger</h1>
        <p className="text-muted-foreground">
          Manually register a new passenger in the system
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <UserPlus className="h-5 w-5 mr-2" />
            Passenger Information
          </CardTitle>
          <CardDescription>
            Enter the passenger's details below
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Changed: Added national_id as the primary lookup field */}
              {/* Changed: Removed onBlur handler, now using debounced auto-lookup */}
              <FormField
                control={form.control}
                name="national_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-lg font-semibold">National ID / Passenger ID *</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="e.g., A123456789" 
                        {...field}
                        disabled={isLookingUp}
                        data-testid="input-national-id"
                      />
                    </FormControl>
                    <FormMessage />
                    {isLookingUp && (
                      <p className="text-sm text-muted-foreground">Looking up passenger...</p>
                    )}
                    {existingPassenger && (
                      <p className="text-sm text-green-600">
                        ✓ Existing passenger found. Update their information below.
                      </p>
                    )}
                    <p className="text-sm text-muted-foreground">
                      Enter the passenger's National ID. System will auto-lookup as you type.
                    </p>
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="first_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>First Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John" {...field} data-testid="input-first-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="last_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Last Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Doe" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="date_of_birth"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date of Birth</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="nationality"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nationality</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., American" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="passport_number"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Passport Number (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., P1234567" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email (Optional)</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="john@example.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone (Optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="+1 234 567 8900" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-2">
                <FormLabel>Passenger Photo</FormLabel>
                <div className="flex items-center gap-4">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoChange}
                    className="flex-1"
                  />
                  <Upload className="h-5 w-5 text-muted-foreground" />
                </div>
                {photoPreview && (
                  <div className="mt-2">
                    <img
                      src={photoPreview}
                      alt="Passenger preview"
                      className="h-32 w-32 object-cover rounded-lg border"
                    />
                  </div>
                )}
                <p className="text-sm text-muted-foreground">
                  Upload a clear photo for scanner identification
                </p>
              </div>

              <div className="flex gap-4 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate('/dashboard')}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1"
                >
                  {isSubmitting ? 'Creating...' : 'Create Passenger'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
};

export default CreatePassenger;
