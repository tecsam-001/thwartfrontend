import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ScanLine, AlertTriangle, Database } from 'lucide-react';
import thwartLogo from '@/assets/thwart-logo-transparent.png';
import { useAuth } from '@/contexts/AuthContext';

const Landing: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  // Redirect authenticated users to dashboard
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <div className="flex justify-center mb-6">
            <img 
              src={thwartLogo} 
              alt="THWART Logo" 
              className="h-48 w-auto"
            />
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-gradient-primary bg-clip-text text-transparent">
            THWART Security System
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Advanced passenger screening and incident management for secure operations
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="bg-card p-8 rounded-lg border border-border text-center">
            <ScanLine className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">Quick Scan</h3>
            <p className="text-muted-foreground">
              Instant QR/barcode scanning for rapid passenger verification
            </p>
          </div>

          <div className="bg-card p-8 rounded-lg border border-border text-center">
            <AlertTriangle className="h-12 w-12 text-warning mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">Incident Tracking</h3>
            <p className="text-muted-foreground">
              Real-time incident reporting with AI-powered severity assessment
            </p>
          </div>

          <div className="bg-card p-8 rounded-lg border border-border text-center">
            <Database className="h-12 w-12 text-success mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">Secure Database</h3>
            <p className="text-muted-foreground">
              Centralized passenger records with restriction management
            </p>
          </div>
        </div>

        <div className="text-center">
          <Link to="/login">
            <Button size="lg" className="text-lg px-8 py-6">
              Access System
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Landing;
