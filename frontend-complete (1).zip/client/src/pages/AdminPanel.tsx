import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  ShieldAlert, 
  CheckCircle, 
  XCircle, 
  Loader2, 
  AlertTriangle,
  FileText,
  Trash2,
  Edit,
  Brain,
  Clock,
  Upload,
  Download,
  Mail
} from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { BulkImportTab } from '@/components/BulkImportTab';

interface Restriction {
  id: string;
  passenger_id: string;
  passenger_name?: string;
  reason: string;
  restriction_type: string;
  severity: string;
  start_date: string;
  end_date: string | null;
  status: string;
  ai_suggestion?: string | null;
  ai_confidence?: number | null;
  auto_approved_at?: string | null;
  approved_at?: string | null;
  created_by: string | null;
  approved_by: string | null;
  created_at: string;
}

interface Incident {
  id: string;
  passenger_id: string;
  passenger_name?: string;
  incident_type: string;
  description: string;
  severity: string;
  location: string | null;
  created_at: string;
  ai_suggestion?: string | null;
}

interface Appeal {
  id: string;
  restriction_id: string;
  passenger_id: string;
  reason: string;
  status: string;
  document_url?: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
}

const AdminPanel: React.FC = () => {
  const navigate = useNavigate();
  const [restrictions, setRestrictions] = useState<Restriction[]>([]);
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [appeals, setAppeals] = useState<Appeal[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isAutoApproving, setIsAutoApproving] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editEndDate, setEditEndDate] = useState('');

  useEffect(() => {
    checkAdminAuth();
  }, []);

  const checkAdminAuth = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      toast.error('Please log in first');
      navigate('/login');
      return;
    }

    const { data: roles } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', session.user.id)
      .eq('role', 'admin')
      .maybeSingle();

    if (!roles) {
      toast.error('Admin access required');
      navigate('/admin-login');
      return;
    }

    // Load all data
    await Promise.all([fetchRestrictions(), fetchIncidents(), fetchAppeals()]);
  };

  const fetchRestrictions = async () => {
    setIsLoading(true);
    try {
      // Force fresh data by adding timestamp to query
      const { data, error } = await supabase
        .from('restrictions')
        .select(`
          *,
          passengers (name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formatted = (data || []).map((r: any) => ({
        ...r,
        passenger_name: r.passengers?.name || 'Unknown Patron',
      }));

      console.log('[AdminPanel] Fetched restrictions:', formatted.length);
      setRestrictions(formatted);
    } catch (error: any) {
      console.error('[AdminPanel] Error fetching restrictions:', error);
      toast.error('Failed to load restrictions');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchIncidents = async () => {
    try {
      // Force fresh data
      const { data, error } = await supabase
        .from('incidents')
        .select(`
          *,
          passengers (name)
        `)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      const formatted = (data || []).map((i: any) => ({
        ...i,
        passenger_name: i.passengers?.name || 'Unknown Patron',
      }));

      console.log('[AdminPanel] Fetched incidents:', formatted.length);
      setIncidents(formatted);
    } catch (error: any) {
      console.error('[AdminPanel] Error fetching incidents:', error);
      toast.error('Failed to load incidents');
    }
  };

  const fetchAppeals = async () => {
    try {
      const { data, error } = await supabase
        .from('appeals')
        .select('*')
        .order('created_at', { ascending: false})
        .limit(50);

      if (error) throw error;

      setAppeals(data || []);
    } catch (error: any) {
      console.error('[AdminPanel] Error fetching appeals:', error);
      toast.error('Failed to load appeals');
    }
  };

  const handleApprove = async (id: string) => {
    try {
      const { error } = await supabase
        .from('restrictions')
        .update({ 
          status: 'approved',
          approved_at: new Date().toISOString()
        })
        .eq('id', id);

      if (error) throw error;

      toast.success('Restriction approved');
      await fetchRestrictions();
    } catch (error: any) {
      toast.error('Failed to approve restriction');
    }
  };

  const handleDecline = async (id: string) => {
    try {
      const { error } = await supabase
        .from('restrictions')
        .update({ status: 'declined' })
        .eq('id', id);

      if (error) throw error;

      toast.success('Restriction declined');
      await fetchRestrictions();
    } catch (error: any) {
      toast.error('Failed to decline restriction');
    }
  };

  const handleApproveIncident = async (incident: Incident) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Not authenticated');
        return;
      }

      // Calculate end date based on severity (30, 60, or 90 days)
      // Normalize severity to lowercase to handle any case variations
      const severityLower = (incident.severity || 'medium').toLowerCase();
      const daysMap: Record<string, number> = {
        low: 30,
        medium: 60,
        high: 90,
        critical: 90,
      };
      const days = daysMap[severityLower] || 60;
      const endDate = new Date();
      endDate.setDate(endDate.getDate() + days);

      // Create restriction from incident
      const { error: restrictionError } = await supabase
        .from('restrictions')
        .insert({
          passenger_id: incident.passenger_id,
          reason: `Incident: ${incident.incident_type} - ${incident.description}`,
          restriction_type: 'alcohol_service',
          severity: incident.severity,
          status: 'approved',
          start_date: new Date().toISOString(),
          end_date: endDate.toISOString(),
          created_by: session.user.id,
          approved_by: session.user.id,
          approved_at: new Date().toISOString(),
        });

      if (restrictionError) throw restrictionError;

      // Delete the incident after creating restriction
      // If this fails, warn admin but don't roll back restriction
      const { error: deleteError } = await supabase
        .from('incidents')
        .delete()
        .eq('id', incident.id);

      if (deleteError) {
        console.error('Failed to delete incident after creating restriction:', deleteError);
        toast.error('Restriction created but incident deletion failed. Please delete incident manually.');
      } else {
        toast.success(`Incident approved and ${days}-day restriction created`);
      }

      await Promise.all([fetchRestrictions(), fetchIncidents()]);
    } catch (error: any) {
      console.error('Approve incident error:', error);
      toast.error('Failed to approve incident');
    }
  };

  const handleDelete = async (id: string, type: 'restriction' | 'incident') => {
    if (!confirm(`Are you sure you want to delete this ${type}?`)) return;

    try {
      console.log(`[AdminPanel] Deleting ${type}:`, id);
      const table = type === 'restriction' ? 'restrictions' : 'incidents';
      const { error } = await supabase
        .from(table)
        .delete()
        .eq('id', id);

      if (error) throw error;

      console.log(`[AdminPanel] ${type} deleted successfully, refreshing...`);
      toast.success(`${type} deleted`);
      
      // Force immediate refresh
      if (type === 'restriction') {
        await fetchRestrictions();
      } else {
        await fetchIncidents();
      }
    } catch (error: any) {
      console.error(`[AdminPanel] Delete error:`, error);
      toast.error(`Failed to delete ${type}`);
    }
  };

  const handleEdit = async (id: string) => {
    if (!editEndDate) {
      toast.error('Please select an end date');
      return;
    }

    try {
      const { error } = await supabase
        .from('restrictions')
        .update({ end_date: editEndDate })
        .eq('id', id);

      if (error) throw error;

      toast.success('Restriction updated');
      setEditingId(null);
      setEditEndDate('');
      await fetchRestrictions();
    } catch (error: any) {
      toast.error('Failed to update restriction');
    }
  };

  const handleAutoApprove = async () => {
    setIsAutoApproving(true);
    try {
      // Call the SQL function
      const { error } = await supabase.rpc('auto_approve_old_restrictions');

      if (error) throw error;

      toast.success('Auto-approval completed');
      await fetchRestrictions();
    } catch (error: any) {
      console.error('Auto-approve error:', error);
      toast.error('Auto-approval failed');
    } finally {
      setIsAutoApproving(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, any> = {
      pending: { variant: 'secondary', label: 'Pending' },
      approved: { variant: 'default', label: 'Approved' },
      declined: { variant: 'destructive', label: 'Declined' },
    };
    const config = variants[status] || variants.pending;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold mb-2">Admin Panel</h1>
          <p className="text-muted-foreground">
            Manage restrictions, incidents, and appeals
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={handleAutoApprove} 
            disabled={isAutoApproving}
            data-testid="button-auto-approve"
          >
            {isAutoApproving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            <Clock className="mr-2 h-4 w-4" />
            Auto-Approve (24h+)
          </Button>
        </div>
      </div>

      <Tabs defaultValue="restrictions" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="restrictions">
            <ShieldAlert className="h-4 w-4 mr-2" />
            Restrictions ({restrictions.length})
          </TabsTrigger>
          <TabsTrigger value="incidents">
            <AlertTriangle className="h-4 w-4 mr-2" />
            Incidents ({incidents.length})
          </TabsTrigger>
          <TabsTrigger value="appeals">
            <FileText className="h-4 w-4 mr-2" />
            Appeals ({appeals.length})
          </TabsTrigger>
          <TabsTrigger value="bulk-import" data-testid="tab-bulk-import">
            <Upload className="h-4 w-4 mr-2" />
            Bulk Import
          </TabsTrigger>
        </TabsList>

        {/* RESTRICTIONS TAB */}
        <TabsContent value="restrictions" className="space-y-4">
          {isLoading ? (
            <div className="text-center py-12">
              <Loader2 className="h-12 w-12 animate-spin mx-auto text-primary" />
            </div>
          ) : restrictions.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <ShieldAlert className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No restrictions found</p>
              </CardContent>
            </Card>
          ) : (
            restrictions.map((restriction) => (
              <Card key={restriction.id}>
                <CardHeader>
                  <div className="flex justify-between items-start flex-wrap gap-2">
                    <div className="flex-1">
                      <CardTitle className="mb-2 flex items-center gap-2">
                        {restriction.passenger_name}
                        {restriction.auto_approved_at && (
                          <Badge variant="outline" className="text-xs">
                            <Clock className="h-3 w-3 mr-1" />
                            Auto-Approved
                          </Badge>
                        )}
                      </CardTitle>
                      <div className="text-sm text-muted-foreground space-y-1">
                        <div>Restriction ID: {restriction.id.substring(0, 8)}</div>
                        <div>Severity: {restriction.severity}</div>
                        {restriction.status === 'approved' && restriction.end_date && (() => {
                          const now = new Date();
                          const endDate = new Date(restriction.end_date);
                          const diffTime = endDate.getTime() - now.getTime();
                          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                          
                          if (diffDays > 0) {
                            return (
                              <div className="flex items-center gap-1 text-orange-600 dark:text-orange-400 font-medium">
                                <Clock className="h-3 w-3" />
                                {diffDays} {diffDays === 1 ? 'day' : 'days'} remaining
                              </div>
                            );
                          } else {
                            return (
                              <div className="flex items-center gap-1 text-red-600 dark:text-red-400 font-medium">
                                <Clock className="h-3 w-3" />
                                Expired
                              </div>
                            );
                          }
                        })()}
                      </div>
                    </div>
                    <div className="flex flex-col gap-2 items-end">
                      {getStatusBadge(restriction.status)}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* AI Suggestion */}
                  {restriction.ai_suggestion && (
                    <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
                      <div className="flex items-start gap-2">
                        <Brain className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                        <div className="flex-1">
                          <p className="font-semibold text-sm text-blue-900 dark:text-blue-100 mb-1">
                            AI Recommendation
                            {restriction.ai_confidence && (
                              <span className="ml-2 text-xs font-normal">
                                ({Math.round(restriction.ai_confidence * 100)}% confidence)
                              </span>
                            )}
                          </p>
                          <p className="text-sm text-blue-800 dark:text-blue-200">
                            {restriction.ai_suggestion}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  <div>
                    <p className="text-sm font-medium mb-1">Reason:</p>
                    <p className="text-sm text-muted-foreground">{restriction.reason}</p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="font-medium">Start Date:</p>
                      <p className="text-muted-foreground">
                        {new Date(restriction.start_date).toLocaleDateString()}
                      </p>
                    </div>
                    {restriction.end_date && (
                      <div>
                        <p className="font-medium">End Date:</p>
                        <p className="text-muted-foreground">
                          {new Date(restriction.end_date).toLocaleDateString()}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Edit End Date */}
                  {restriction.status === 'approved' && editingId === restriction.id && (
                    <div className="space-y-2 border-t pt-4">
                      <Label htmlFor={`edit-date-${restriction.id}`}>Edit End Date</Label>
                      <div className="flex gap-2">
                        <Input
                          id={`edit-date-${restriction.id}`}
                          type="date"
                          value={editEndDate}
                          onChange={(e) => setEditEndDate(e.target.value)}
                        />
                        <Button onClick={() => handleEdit(restriction.id)} size="sm">
                          Save
                        </Button>
                        <Button 
                          onClick={() => {
                            setEditingId(null);
                            setEditEndDate('');
                          }} 
                          variant="outline" 
                          size="sm"
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex gap-2 pt-4 border-t flex-wrap">
                    {restriction.status === 'pending' && (
                      <>
                        <Button
                          size="sm"
                          onClick={() => handleApprove(restriction.id)}
                          className="flex-1"
                        >
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDecline(restriction.id)}
                          className="flex-1"
                        >
                          <XCircle className="h-4 w-4 mr-2" />
                          Decline
                        </Button>
                      </>
                    )}
                    {restriction.status === 'approved' && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setEditingId(restriction.id);
                            setEditEndDate(restriction.end_date || '');
                          }}
                          disabled={editingId === restriction.id}
                        >
                          <Edit className="h-4 w-4 mr-2" />
                          Edit Duration
                        </Button>
                        <Button
                          size="sm"
                          variant="default"
                          onClick={async () => {
                            try {
                              const { data: { session } } = await supabase.auth.getSession();
                              if (!session) {
                                toast.error('Authentication required');
                                return;
                              }
                              
                              const response = await fetch(`/api/restrictions/${restriction.id}/letter`, {
                                headers: {
                                  'Authorization': `Bearer ${session.access_token}`
                                }
                              });
                              
                              if (!response.ok) {
                                throw new Error('Failed to generate letter');
                              }
                              
                              const blob = await response.blob();
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = `Restriction_Letter_${restriction.id.substring(0, 8)}.pdf`;
                              document.body.appendChild(a);
                              a.click();
                              window.URL.revokeObjectURL(url);
                              document.body.removeChild(a);
                              
                              toast.success('Letter downloaded');
                            } catch (error) {
                              console.error('Letter generation error:', error);
                              toast.error('Failed to generate letter');
                            }
                          }}
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Download PDF
                        </Button>
                        <Button
                          size="sm"
                          variant="default"
                          data-testid={`button-send-email-${restriction.id}`}
                          onClick={async () => {
                            try {
                              const { data: { session } } = await supabase.auth.getSession();
                              if (!session) {
                                toast.error('Authentication required');
                                return;
                              }
                              
                              toast.loading('Sending email...', { id: 'email-send' });
                              
                              const response = await fetch(`/api/restrictions/${restriction.id}/send-email`, {
                                method: 'POST',
                                headers: {
                                  'Authorization': `Bearer ${session.access_token}`,
                                  'Content-Type': 'application/json'
                                }
                              });
                              
                              const result = await response.json();
                              
                              if (!response.ok) {
                                throw new Error(result.message || 'Failed to send email');
                              }
                              
                              toast.success(`Email sent to ${result.sentTo}`, { id: 'email-send' });
                            } catch (error: any) {
                              console.error('Email sending error:', error);
                              toast.error(error.message || 'Failed to send email', { id: 'email-send' });
                            }
                          }}
                        >
                          <Mail className="h-4 w-4 mr-2" />
                          Send Email
                        </Button>
                      </>
                    )}
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDelete(restriction.id, 'restriction')}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        {/* INCIDENTS TAB */}
        <TabsContent value="incidents" className="space-y-4">
          {incidents.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <AlertTriangle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No incidents reported</p>
              </CardContent>
            </Card>
          ) : (
            incidents.map((incident) => (
              <Card key={incident.id}>
                <CardHeader>
                  <div className="flex justify-between items-start flex-wrap gap-2">
                    <div className="flex-1">
                      <CardTitle className="mb-2">{incident.passenger_name}</CardTitle>
                      <div className="text-sm text-muted-foreground space-y-1">
                        <div>Incident ID: {incident.id.substring(0, 8)}</div>
                        <div>{incident.incident_type} - {new Date(incident.created_at).toLocaleDateString()}</div>
                      </div>
                    </div>
                    <Badge 
                      variant={
                        incident.severity === 'critical' || incident.severity === 'high' 
                          ? 'destructive' 
                          : 'secondary'
                      }
                    >
                      {incident.severity}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {incident.ai_suggestion && (
                    <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
                      <div className="flex items-start gap-2">
                        <Brain className="h-4 w-4 text-blue-600 mt-0.5" />
                        <p className="text-sm text-blue-800 dark:text-blue-200">
                          {incident.ai_suggestion}
                        </p>
                      </div>
                    </div>
                  )}
                  <p className="text-sm">{incident.description}</p>
                  {incident.location && (
                    <p className="text-sm text-muted-foreground">Location: {incident.location}</p>
                  )}
                  <div className="flex gap-2 pt-2 border-t flex-wrap">
                    <Button
                      size="sm"
                      onClick={() => handleApproveIncident(incident)}
                      className="flex-1"
                      data-testid={`button-approve-incident-${incident.id}`}
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Approve & Create Restriction
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDelete(incident.id, 'incident')}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        {/* APPEALS TAB */}
        <TabsContent value="appeals" className="space-y-4">
          {appeals.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No appeals submitted</p>
              </CardContent>
            </Card>
          ) : (
            appeals.map((appeal) => (
              <Card key={appeal.id}>
                <CardHeader>
                  <div className="flex justify-between items-start flex-wrap gap-2">
                    <div className="flex-1">
                      <CardTitle className="mb-2">Appeal #{appeal.id.substring(0, 8)}</CardTitle>
                      <CardDescription>
                        Submitted: {new Date(appeal.created_at).toLocaleDateString()}
                      </CardDescription>
                    </div>
                    <Badge variant={appeal.status === 'pending' ? 'secondary' : 'default'}>
                      {appeal.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <p className="text-sm font-medium">Reason:</p>
                    <p className="text-sm text-muted-foreground">{appeal.reason}</p>
                  </div>
                  {appeal.document_url && (
                    <div>
                      <a 
                        href={appeal.document_url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-sm text-primary hover:underline"
                      >
                        View Supporting Document →
                      </a>
                    </div>
                  )}
                  <div className="text-sm text-muted-foreground">
                    <strong>Restriction ID:</strong> {appeal.restriction_id.substring(0, 8)}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        {/* BULK IMPORT TAB */}
        <TabsContent value="bulk-import" className="space-y-4">
          <BulkImportTab />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminPanel;
