import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { AlertTriangle, UserPlus, Upload } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

const Incident: React.FC = () => {
  const { user } = useAuth();
  // Changed: Now stores national_id instead of passenger UUID
  const [formData, setFormData] = useState({
    national_id: '', // Changed from passenger_id to national_id for user input
    passenger_name: '',
    passenger_address: '',
    passenger_dob: '',
    incident_type: '',
    severity: 'medium',
    description: '',
    location: '',
    reported_by: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [passenger, setPassenger] = useState<any>(null);
  const [isLookingUpPassenger, setIsLookingUpPassenger] = useState(false); // Track lookup state
  const [showCreatePassenger, setShowCreatePassenger] = useState(false);
  const [isCreatingPassenger, setIsCreatingPassenger] = useState(false);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [newPassengerData, setNewPassengerData] = useState({
    first_name: '',
    last_name: '',
    date_of_birth: '',
    nationality: '',
    address: '',
    passport_number: '',
    email: '',
    phone: '',
  });

  useEffect(() => {
    if (user?.id) {
      setFormData(prev => ({ ...prev, reported_by: user.id }));
    }
  }, [user]);

  // Changed: Now fetches passenger by national_id instead of UUID with normalization
  // CRITICAL FIX: Immediately clear passenger state to prevent stale data submission
  useEffect(() => {
    const normalizedId = formData.national_id.trim().toUpperCase();
    
    // Immediately clear passenger and set loading state when ID changes
    setPassenger(null);
    
    if (!normalizedId || normalizedId.length < 3) {
      setIsLookingUpPassenger(false);
      return;
    }

    setIsLookingUpPassenger(true);

    const fetchPassenger = async () => {
      const { data, error } = await supabase
        .from('passengers')
        .select('*')
        .eq('national_id', normalizedId) // Changed: lookup by normalized national_id
        .maybeSingle();

      if (error) {
        console.error('Error fetching passenger:', error);
        setPassenger(null);
      } else {
        setPassenger(data);
      }
      setIsLookingUpPassenger(false);
    };

    // Debounce the lookup by 500ms
    const timer = setTimeout(fetchPassenger, 500);
    return () => {
      clearTimeout(timer);
      setIsLookingUpPassenger(false);
    };
  }, [formData.national_id]);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file size (5MB limit)
      const maxSize = 5 * 1024 * 1024; // 5MB in bytes
      if (file.size > maxSize) {
        toast({
          title: 'File too large',
          description: 'Photo must be less than 5MB',
          variant: 'destructive',
        });
        e.target.value = ''; // Clear the input
        return;
      }

      // Validate file type (images only)
      const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
      if (!allowedTypes.includes(file.type)) {
        toast({
          title: 'Invalid file type',
          description: 'Please upload a valid image file (JPEG, PNG, GIF, or WebP)',
          variant: 'destructive',
        });
        e.target.value = ''; // Clear the input
        return;
      }

      setPhotoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreatePassenger = async () => {
    // Validate National ID
    const normalizedNationalId = formData.national_id.trim().toUpperCase();
    if (!normalizedNationalId || normalizedNationalId.length === 0) {
      toast({
        title: 'National ID required',
        description: 'Please enter a National ID first',
        variant: 'destructive',
      });
      return;
    }

    if (normalizedNationalId.length > 50) {
      toast({
        title: 'National ID too long',
        description: 'National ID must be 50 characters or less',
        variant: 'destructive',
      });
      return;
    }

    // Validate required fields with length limits
    if (!newPassengerData.first_name?.trim() || newPassengerData.first_name.trim().length === 0) {
      toast({
        title: 'First name required',
        description: 'Please enter the passenger\'s first name',
        variant: 'destructive',
      });
      return;
    }

    if (newPassengerData.first_name.length > 100) {
      toast({
        title: 'First name too long',
        description: 'First name must be 100 characters or less',
        variant: 'destructive',
      });
      return;
    }

    if (!newPassengerData.last_name?.trim() || newPassengerData.last_name.trim().length === 0) {
      toast({
        title: 'Last name required',
        description: 'Please enter the passenger\'s last name',
        variant: 'destructive',
      });
      return;
    }

    if (newPassengerData.last_name.length > 100) {
      toast({
        title: 'Last name too long',
        description: 'Last name must be 100 characters or less',
        variant: 'destructive',
      });
      return;
    }

    if (!newPassengerData.date_of_birth) {
      toast({
        title: 'Date of birth required',
        description: 'Please enter the passenger\'s date of birth',
        variant: 'destructive',
      });
      return;
    }

    if (!newPassengerData.nationality?.trim() || newPassengerData.nationality.trim().length === 0) {
      toast({
        title: 'Nationality required',
        description: 'Please enter the passenger\'s nationality',
        variant: 'destructive',
      });
      return;
    }

    if (newPassengerData.nationality.length > 100) {
      toast({
        title: 'Nationality too long',
        description: 'Nationality must be 100 characters or less',
        variant: 'destructive',
      });
      return;
    }

    if (!newPassengerData.address?.trim() || newPassengerData.address.trim().length === 0) {
      toast({
        title: 'Address required',
        description: 'Please enter the passenger\'s address',
        variant: 'destructive',
      });
      return;
    }

    if (newPassengerData.address.length > 500) {
      toast({
        title: 'Address too long',
        description: 'Address must be 500 characters or less',
        variant: 'destructive',
      });
      return;
    }

    // Validate optional email if provided
    if (newPassengerData.email && newPassengerData.email.trim().length > 0) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(newPassengerData.email)) {
        toast({
          title: 'Invalid email',
          description: 'Please enter a valid email address or leave it blank',
          variant: 'destructive',
        });
        return;
      }
    }

    setIsCreatingPassenger(true);
    try {
      // Prepare form data for multipart/form-data submission
      const formData = new FormData();
      formData.append('national_id', normalizedNationalId);
      formData.append('first_name', newPassengerData.first_name.trim());
      formData.append('last_name', newPassengerData.last_name.trim());
      formData.append('date_of_birth', newPassengerData.date_of_birth);
      formData.append('nationality', newPassengerData.nationality.trim());
      formData.append('address', newPassengerData.address.trim());
      
      if (newPassengerData.passport_number?.trim()) {
        formData.append('passport_number', newPassengerData.passport_number.trim());
      }
      if (newPassengerData.email?.trim()) {
        formData.append('email', newPassengerData.email.trim());
      }
      if (newPassengerData.phone?.trim()) {
        formData.append('phone', newPassengerData.phone.trim());
      }
      if (photoFile) {
        formData.append('photo', photoFile);
      }

      // Call secure server-side API endpoint
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      const response = await fetch('/api/passengers', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to create passenger');
      }

      const result = await response.json();
      const createdPassenger = result.data;

      toast({
        title: 'Passenger created',
        description: `${createdPassenger.name} has been added successfully`,
      });

      setPassenger(createdPassenger);
      setShowCreatePassenger(false);
      setNewPassengerData({
        first_name: '',
        last_name: '',
        date_of_birth: '',
        nationality: '',
        address: '',
        passport_number: '',
        email: '',
        phone: '',
      });
      setPhotoFile(null);
      setPhotoPreview(null);
    } catch (error: any) {
      toast({
        title: 'Creation failed',
        description: error.message || 'Unable to create passenger',
        variant: 'destructive',
      });
    } finally {
      setIsCreatingPassenger(false);
    }
  };

  // Changed: Now uses passenger.id (UUID) from the looked-up passenger record
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate that passenger was found
    if (!passenger) {
      toast({
        title: 'Passenger not found',
        description: 'Please enter a valid National ID to find the passenger',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const { error } = await supabase
        .from('incidents')
        .insert({
          passenger_id: passenger.id, // Changed: Use the UUID from passenger lookup
          incident_type: formData.incident_type,
          severity: formData.severity,
          description: formData.description,
          location: formData.location,
          reported_by: formData.reported_by,
        });

      if (error) throw error;

      toast({
        title: 'Incident reported',
        description: 'The incident has been recorded successfully',
      });

      // Reset form
      setFormData({
        national_id: '', // Changed: reset national_id field
        passenger_name: '',
        passenger_address: '',
        passenger_dob: '',
        incident_type: '',
        severity: 'medium',
        description: '',
        location: '',
        reported_by: user?.id || '',
      });
      setPassenger(null);
    } catch (error: any) {
      toast({
        title: 'Report failed',
        description: error.message || 'Unable to submit incident report',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Report Incident</h1>
        <p className="text-muted-foreground">
          Document passenger incidents with photo identification
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardDescription>
            All fields are required for proper documentation
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Changed: Input field now uses national_id instead of passenger UUID */}
            <div className="space-y-2">
              <Label htmlFor="national_id">National ID / Passenger ID *</Label>
              <Input
                id="national_id"
                placeholder="e.g., A123456789"
                value={formData.national_id}
                onChange={(e) => setFormData({ ...formData, national_id: e.target.value })}
                required
                disabled={isLookingUpPassenger}
                data-testid="input-national-id"
              />
              {isLookingUpPassenger && (
                <p className="text-sm text-muted-foreground">
                  Looking up passenger...
                </p>
              )}
              {formData.national_id.trim().length >= 3 && !passenger && !isLookingUpPassenger && (
                <div className="space-y-3 p-4 bg-yellow-500/10 dark:bg-yellow-500/20 border-2 border-yellow-500/50 rounded-md">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="h-5 w-5 text-yellow-600 dark:text-yellow-500 mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-yellow-900 dark:text-yellow-100 mb-1">
                        Patron Not Found
                      </p>
                      <p className="text-sm text-yellow-800 dark:text-yellow-200">
                        No patron exists with National ID: <span className="font-mono font-bold">{formData.national_id.trim().toUpperCase()}</span>
                      </p>
                    </div>
                  </div>
                  <Button
                    type="button"
                    variant="default"
                    size="default"
                    onClick={() => setShowCreatePassenger(!showCreatePassenger)}
                    className="w-full"
                    data-testid="button-toggle-create-passenger"
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    {showCreatePassenger ? 'Cancel New Patron' : 'Add New Patron'}
                  </Button>
                </div>
              )}
              {!formData.national_id.trim() && (
                <p className="text-sm text-muted-foreground">
                  Enter the passenger's National ID to lookup their information. If not found, you can create a new patron.
                </p>
              )}
            </div>

            {/* Passenger Information Fields */}
            <div className="space-y-2">
              <Label htmlFor="passenger_name">Passenger Name *</Label>
              <Input
                id="passenger_name"
                placeholder="e.g., John Doe"
                value={formData.passenger_name}
                onChange={(e) => setFormData({ ...formData, passenger_name: e.target.value })}
                required
                data-testid="input-passenger-name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="passenger_address">Address *</Label>
              <Input
                id="passenger_address"
                placeholder="e.g., 123 Main Street, City"
                value={formData.passenger_address}
                onChange={(e) => setFormData({ ...formData, passenger_address: e.target.value })}
                required
                data-testid="input-passenger-address"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="passenger_dob">Date of Birth *</Label>
              <Input
                id="passenger_dob"
                type="date"
                value={formData.passenger_dob}
                onChange={(e) => setFormData({ ...formData, passenger_dob: e.target.value })}
                required
                data-testid="input-passenger-dob"
              />
            </div>

            {/* NEW: Passenger creation form - shown when no passenger found */}
            {showCreatePassenger && !passenger && formData.national_id.trim().length >= 3 && (
              <Card className="border-primary/50">
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <UserPlus className="h-5 w-5 mr-2" />
                    Add New Patron
                  </CardTitle>
                  <CardDescription>
                    Create a new patron profile with National ID: {formData.national_id.trim().toUpperCase()}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="new_first_name">First Name *</Label>
                      <Input
                        id="new_first_name"
                        placeholder="John"
                        value={newPassengerData.first_name}
                        onChange={(e) => setNewPassengerData({ ...newPassengerData, first_name: e.target.value })}
                        required
                        data-testid="input-new-first-name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="new_last_name">Last Name *</Label>
                      <Input
                        id="new_last_name"
                        placeholder="Doe"
                        value={newPassengerData.last_name}
                        onChange={(e) => setNewPassengerData({ ...newPassengerData, last_name: e.target.value })}
                        required
                        data-testid="input-new-last-name"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="new_date_of_birth">Date of Birth *</Label>
                      <Input
                        id="new_date_of_birth"
                        type="date"
                        value={newPassengerData.date_of_birth}
                        onChange={(e) => setNewPassengerData({ ...newPassengerData, date_of_birth: e.target.value })}
                        required
                        data-testid="input-new-dob"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="new_nationality">Nationality *</Label>
                      <Input
                        id="new_nationality"
                        placeholder="e.g., British"
                        value={newPassengerData.nationality}
                        onChange={(e) => setNewPassengerData({ ...newPassengerData, nationality: e.target.value })}
                        required
                        data-testid="input-new-nationality"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new_address">Address *</Label>
                    <Input
                      id="new_address"
                      placeholder="e.g., 123 Main Street, City"
                      value={newPassengerData.address}
                      onChange={(e) => setNewPassengerData({ ...newPassengerData, address: e.target.value })}
                      required
                      data-testid="input-new-address"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new_passport_number">Passport Number</Label>
                    <Input
                      id="new_passport_number"
                      placeholder="Optional"
                      value={newPassengerData.passport_number}
                      onChange={(e) => setNewPassengerData({ ...newPassengerData, passport_number: e.target.value })}
                      data-testid="input-new-passport"
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="new_email">Email</Label>
                      <Input
                        id="new_email"
                        type="email"
                        placeholder="Optional"
                        value={newPassengerData.email}
                        onChange={(e) => setNewPassengerData({ ...newPassengerData, email: e.target.value })}
                        data-testid="input-new-email"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="new_phone">Phone</Label>
                      <Input
                        id="new_phone"
                        type="tel"
                        placeholder="Optional"
                        value={newPassengerData.phone}
                        onChange={(e) => setNewPassengerData({ ...newPassengerData, phone: e.target.value })}
                        data-testid="input-new-phone"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new_photo">Patron Photo</Label>
                    <div className="flex items-center gap-4">
                      {photoPreview && (
                        <Avatar className="h-20 w-20">
                          <AvatarImage src={photoPreview} alt="Preview" />
                          <AvatarFallback>Photo</AvatarFallback>
                        </Avatar>
                      )}
                      <div className="flex-1">
                        <Input
                          id="new_photo"
                          type="file"
                          accept="image/*"
                          onChange={handlePhotoChange}
                          data-testid="input-new-photo"
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          Optional. Max size: 5MB
                        </p>
                      </div>
                    </div>
                  </div>

                  <Button
                    type="button"
                    onClick={handleCreatePassenger}
                    disabled={isCreatingPassenger}
                    className="w-full"
                    data-testid="button-create-passenger"
                  >
                    {isCreatingPassenger ? 'Creating Patron...' : 'Create Patron & Continue'}
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Changed: Passenger card now shows national_id */}
            {passenger && (
              <Card className="bg-muted/50">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4">
                    <Avatar className="h-20 w-20">
                      <AvatarImage src={passenger.photo_url || ''} alt={passenger.name} />
                      <AvatarFallback className="text-lg">
                        {passenger.name.split(' ').map((n: string) => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className="space-y-1">
                      <h3 className="font-semibold text-lg">{passenger.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        National ID: {passenger.national_id || 'N/A'}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Date of Birth: {passenger.date_of_birth || 'N/A'}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Nationality: {passenger.nationality}
                      </p>
                      {passenger.address && (
                        <p className="text-sm text-muted-foreground">
                          Address: {passenger.address}
                        </p>
                      )}
                      <p className="text-sm text-muted-foreground">
                        Passport: {passenger.passport_number || 'N/A'}
                      </p>
                      {passenger.email && (
                        <p className="text-sm text-muted-foreground">
                          Email: {passenger.email}
                        </p>
                      )}
                      {passenger.phone && (
                        <p className="text-sm text-muted-foreground">
                          Phone: {passenger.phone}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="incident_type">Incident Type</Label>
                <Select
                  value={formData.incident_type}
                  onValueChange={(value) => setFormData({ ...formData, incident_type: value })}
                  required
                >
                  <SelectTrigger id="incident_type">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="disruptive_behavior">Disruptive Behavior</SelectItem>
                    <SelectItem value="verbal_abuse">Verbal Abuse</SelectItem>
                    <SelectItem value="physical_altercation">Physical Altercation</SelectItem>
                    <SelectItem value="security_threat">Security Threat</SelectItem>
                    <SelectItem value="medical_emergency">Medical Emergency</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="severity">Severity Level</Label>
                <Select
                  value={formData.severity}
                  onValueChange={(value) => setFormData({ ...formData, severity: value })}
                  required
                >
                  <SelectTrigger id="severity">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">1 - Low</SelectItem>
                    <SelectItem value="medium">2 - Medium</SelectItem>
                    <SelectItem value="high">3 - High</SelectItem>
                    <SelectItem value="critical">4 - Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                placeholder="e.g., Gate 23, Departure Hall"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Incident Description</Label>
              <Textarea
                id="description"
                placeholder="Provide detailed description of the incident..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                required
                rows={5}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="reported_by">Reported By</Label>
              <Input
                id="reported_by"
                value={user?.email || 'Loading...'}
                readOnly
                disabled
                className="bg-muted cursor-not-allowed"
                data-testid="input-reported-by"
              />
              <p className="text-xs text-muted-foreground">
                Auto-filled with your account info
              </p>
            </div>

            {/* Changed: Disable submit button if passenger not found or still looking up */}
            <Button
              type="submit"
              disabled={isSubmitting || !passenger || isLookingUpPassenger}
              className="w-full"
              data-testid="button-submit-incident"
            >
              {isSubmitting ? 'Submitting...' : 'Submit Incident Report'}
            </Button>
            {!passenger && formData.national_id.trim().length >= 3 && !isLookingUpPassenger && (
              <p className="text-sm text-center text-destructive">
                Cannot submit incident until a valid passenger is found
              </p>
            )}
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default Incident;
