import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ArrowLeft, ShieldAlert } from 'lucide-react';
import thwartLogo from '@/assets/thwart-logo-transparent.png';

const Login: React.FC = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login, signUp, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  // Redirect if already authenticated
  React.useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      if (isSignUp) {
        await signUp(email, password, username);
      } else {
        await login(email, password);
      }
      navigate('/dashboard');
    } catch (error) {
      // Error toast handled in AuthContext
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center pt-12 pb-6">
          <div className="flex justify-center">
            <img 
              src={thwartLogo} 
              alt="THWART Logo" 
              className="h-56 w-auto"
              style={{
                filter: 'brightness(0) saturate(100%) invert(47%) sepia(90%) saturate(2127%) hue-rotate(189deg) brightness(98%) contrast(91%)'
              }}
            />
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="block text-center">Partner ID</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter partner ID"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoFocus
                className="text-center"
              />
            </div>
            {isSignUp && (
              <div className="space-y-2">
                <Label htmlFor="username" className="block text-center">Username</Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="Choose a username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="text-center"
                />
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="password" className="block text-center">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                className="text-center"
              />
            </div>
            <Button
              type="submit"
              className="w-full"
              disabled={isLoading}
            >
              {isLoading 
                ? (isSignUp ? 'Creating account...' : 'Logging in...') 
                : (isSignUp ? 'Sign Up' : 'Login')}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex justify-center pb-6">
          <Link 
            to="/admin-login"
            className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-2"
            data-testid="link-admin-access"
          >
            <ShieldAlert className="h-3 w-3" />
            Admin Access
          </Link>
        </CardFooter>
      </Card>
    </div>
  );
};

export default Login;
