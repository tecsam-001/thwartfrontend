import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import thwartLogo from '@/assets/thwart-logo-transparent.png';
import { ShieldCheck } from 'lucide-react';

const AdminSetup: React.FC = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isAuthorized, setIsAuthorized] = useState(false);

  // Check if admin setup is enabled via environment variable
  useEffect(() => {
    const checkSetupAvailability = async () => {
      const setupEnabled = import.meta.env.VITE_ENABLE_ADMIN_SETUP === 'true';
      
      if (!setupEnabled) {
        toast.error('Admin setup is not enabled');
        navigate('/login');
        return;
      }

      // TEMPORARILY DISABLED: Check if admin already exists
      // This allows creating a fresh admin if previous attempts failed
      /*
      const { data: existingAdmin } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'admin')
        .limit(1);

      if (existingAdmin && existingAdmin.length > 0) {
        toast.error('Admin account already exists. Please disable VITE_ENABLE_ADMIN_SETUP.');
        navigate('/login');
        return;
      }
      */

      setIsAuthorized(true);
    };

    checkSetupAvailability();
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Call the backend API to create admin account
      const response = await fetch('/api/setup/admin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email,
          password,
          username,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Failed to create admin account');
      }

      toast.success('Admin account created successfully!');
      toast.info('Please disable VITE_ENABLE_ADMIN_SETUP in your environment variables');
      
      // Wait a moment for toasts to be visible, then redirect
      setTimeout(() => {
        navigate('/login');
      }, 2000);
    } catch (error: any) {
      console.error('Role assignment error:', error);
      toast.error(error.message || 'Failed to create admin account');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isAuthorized) {
    return null;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <img 
              src={thwartLogo} 
              alt="THWART Logo" 
              className="h-32 w-auto"
              style={{
                filter: 'brightness(0) saturate(100%) invert(45%) sepia(85%) saturate(2000%) hue-rotate(190deg) brightness(100%) contrast(95%)'
              }}
            />
          </div>
          <div className="flex items-center justify-center gap-2 mb-2">
            <ShieldCheck className="h-6 w-6 text-primary" />
            <CardTitle className="text-2xl">Admin Setup</CardTitle>
          </div>
          <CardDescription>
            Create your admin account (one-time setup)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="admin@thwart.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoFocus
                data-testid="input-admin-email"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                type="text"
                placeholder="admin"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                data-testid="input-admin-username"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Choose a strong password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                data-testid="input-admin-password"
              />
              <p className="text-xs text-muted-foreground">
                💡 Your browser will offer to save this password
              </p>
            </div>
            <Button
              type="submit"
              className="w-full"
              disabled={isLoading}
              data-testid="button-create-admin"
            >
              {isLoading ? 'Creating Admin Account...' : 'Create Admin Account'}
            </Button>
          </form>
          <div className="mt-4 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-md">
            <p className="text-xs text-muted-foreground">
              ⚠️ After creating your account, remember to:
              <br />
              1. Save your password in the browser
              <br />
              2. Disable <code className="text-xs bg-muted px-1 py-0.5 rounded">VITE_ENABLE_ADMIN_SETUP</code> in environment variables
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminSetup;
