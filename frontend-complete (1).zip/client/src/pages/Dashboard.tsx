import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Search, AlertTriangle, ShieldAlert } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import StatusBadge from '@/components/StatusBadge';

const Dashboard: React.FC = () => {
  const [stats, setStats] = useState({
    activeRestrictions: 0,
    recentIncidents: 0,
  });
  const [isLoadingStats, setIsLoadingStats] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchStats = async () => {
      try {
        // Fetch active restrictions (pending or approved)
        const { count: restrictionsCount, error: restrictionsError } = await supabase
          .from('restrictions')
          .select('*', { count: 'exact', head: true })
          .in('status', ['pending', 'approved']);

        if (restrictionsError) throw restrictionsError;

        // Fetch recent incidents (last 30 days)
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        
        const { count: incidentsCount, error: incidentsError } = await supabase
          .from('incidents')
          .select('*', { count: 'exact', head: true })
          .gte('created_at', thirtyDaysAgo.toISOString());

        if (incidentsError) throw incidentsError;

        setStats({
          activeRestrictions: restrictionsCount || 0,
          recentIncidents: incidentsCount || 0,
        });
      } catch (error) {
        console.error('Failed to fetch dashboard stats:', error);
        toast({
          title: 'Error loading stats',
          description: 'Could not load dashboard statistics',
          variant: 'destructive',
        });
      } finally {
        setIsLoadingStats(false);
      }
    };

    fetchStats();
  }, []);

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">
          Quick access to serve check and incident report
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <CardTitle className="text-sm font-medium">Active Restricted Passengers</CardTitle>
            <ShieldAlert className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">
              {isLoadingStats ? '...' : stats.activeRestrictions}
            </div>
            <p className="text-xs text-muted-foreground">Currently restricted</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <CardTitle className="text-sm font-medium">Recent Incidents</CardTitle>
            <AlertTriangle className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {isLoadingStats ? '...' : stats.recentIncidents}
            </div>
            <p className="text-xs text-muted-foreground">Last 24 hours</p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => navigate('/scan')}>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Search className="h-5 w-5 mr-2 text-primary" />
              Serve Check
            </CardTitle>
            <CardDescription>
              Use QR/barcode scanner or manual entry
            </CardDescription>
          </CardHeader>
        </Card>

        <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => navigate('/incident')}>
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="h-5 w-5 mr-2 text-warning" />
              Report Incident
            </CardTitle>
            <CardDescription>
              File a new incident report with AI assistance
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
