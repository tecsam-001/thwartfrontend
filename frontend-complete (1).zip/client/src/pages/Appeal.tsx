import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { AlertCircle, CheckCircle, Clock, FileText, Upload } from 'lucide-react';

interface Appeal {
  id: string;
  restriction_id: string;
  passenger_id: string;
  reason: string;
  status: string;
  created_at: string;
  reviewed_at: string | null;
  reviewed_by: string | null;
}

const AppealPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const restrictionId = searchParams.get('restriction_id');
  const passengerId = searchParams.get('passenger_id');

  const [appealReason, setAppealReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [appeals, setAppeals] = useState<Appeal[]>([]);
  const [isLoadingAppeals, setIsLoadingAppeals] = useState(false);
  const [searchPassengerId, setSearchPassengerId] = useState(passengerId || '');
  const [documentFile, setDocumentFile] = useState<File | null>(null);

  const handleDocumentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setDocumentFile(file);
    }
  };

  const loadAppeals = async (pid: string) => {
    if (!pid.trim()) return;
    
    setIsLoadingAppeals(true);
    try {
      const { data, error } = await supabase
        .from('appeals')
        .select('*')
        .eq('passenger_id', pid)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setAppeals(data || []);
    } catch (error: any) {
      toast({
        title: 'Failed to load appeals',
        description: error.message || 'Unable to retrieve appeal history',
        variant: 'destructive',
      });
    } finally {
      setIsLoadingAppeals(false);
    }
  };

  useEffect(() => {
    if (passengerId) {
      loadAppeals(passengerId);
    }
  }, [passengerId]);

  const handleSubmitAppeal = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!restrictionId || !searchPassengerId || !appealReason.trim()) {
      toast({
        title: 'Missing information',
        description: 'Please provide restriction ID, passenger ID, and appeal reason',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);
    try {
      let documentUrl = null;

      // Upload document if provided
      if (documentFile) {
        const fileExt = documentFile.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
        const filePath = `${searchPassengerId}/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('appeal-documents')
          .upload(filePath, documentFile);

        if (uploadError) {
          throw uploadError;
        }

        const { data: urlData } = supabase.storage
          .from('appeal-documents')
          .getPublicUrl(filePath);

        documentUrl = urlData.publicUrl;
      }

      const { error } = await supabase
        .from('appeals')
        .insert({
          restriction_id: restrictionId,
          passenger_id: searchPassengerId,
          reason: appealReason.trim(),
          document_url: documentUrl,
        });

      if (error) throw error;

      toast({
        title: 'Appeal submitted',
        description: 'Your appeal has been submitted successfully and is under review',
      });

      setAppealReason('');
      setDocumentFile(null);
      // Reload appeals
      await loadAppeals(searchPassengerId);
    } catch (error: any) {
      toast({
        title: 'Appeal submission failed',
        description: error.message || 'Unable to submit appeal',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCheckAppeals = (e: React.FormEvent) => {
    e.preventDefault();
    loadAppeals(searchPassengerId);
  };

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'approved':
        return <CheckCircle className="h-4 w-4" />;
      case 'rejected':
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusBadgeVariant = (status: string): "default" | "secondary" | "destructive" | "outline" => {
    switch (status.toLowerCase()) {
      case 'approved':
        return 'default';
      case 'rejected':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Restriction Appeals</h1>
        <p className="text-muted-foreground">
          Submit an appeal against a travel restriction
        </p>
      </div>

      {/* Appeal Submission Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <FileText className="h-5 w-5 mr-2" />
            Submit Appeal
          </CardTitle>
          <CardDescription>
            Provide detailed reasons for your appeal
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmitAppeal} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="restriction_id">Restriction ID</Label>
                <Input
                  id="restriction_id"
                  value={restrictionId || ''}
                  placeholder="e.g., RST-001"
                  readOnly={!!restrictionId}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="passenger_id">Passenger ID</Label>
                <Input
                  id="passenger_id"
                  value={searchPassengerId}
                  onChange={(e) => setSearchPassengerId(e.target.value)}
                  placeholder="e.g., P-001"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="reason">Appeal Reason</Label>
              <Textarea
                id="reason"
                value={appealReason}
                onChange={(e) => setAppealReason(e.target.value)}
                placeholder="Explain in detail why you believe the restriction should be lifted..."
                rows={6}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="document">Supporting Documents (Optional)</Label>
              <div className="flex items-center gap-4">
                <Input
                  id="document"
                  type="file"
                  accept="image/*,.pdf"
                  onChange={handleDocumentChange}
                  className="flex-1"
                />
                <Upload className="h-5 w-5 text-muted-foreground" />
              </div>
              {documentFile && (
                <p className="text-sm text-muted-foreground">
                  Selected: {documentFile.name}
                </p>
              )}
              <p className="text-sm text-muted-foreground">
                Upload photos, documents or evidence supporting your appeal
              </p>
            </div>

            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full"
            >
              {isSubmitting ? 'Submitting...' : 'Submit Appeal'}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Appeal History Section */}
      <Card>
        <CardHeader>
          <CardTitle>Appeal History</CardTitle>
          <CardDescription>
            View previous appeals for a passenger
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCheckAppeals} className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="Enter passenger ID"
                value={searchPassengerId}
                onChange={(e) => setSearchPassengerId(e.target.value)}
              />
              <Button type="submit" disabled={isLoadingAppeals}>
                {isLoadingAppeals ? 'Loading...' : 'Check Appeals'}
              </Button>
            </div>
          </form>

          {appeals.length > 0 && (
            <div className="mt-4 space-y-3">
              {appeals.map((appeal) => (
                <Alert key={appeal.id}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        {getStatusIcon(appeal.status)}
                        <Badge variant={getStatusBadgeVariant(appeal.status)}>
                          {appeal.status}
                        </Badge>
                      </div>
                      <AlertDescription>
                        <div className="space-y-1 text-sm">
                          <p><strong>Restriction ID:</strong> {appeal.restriction_id}</p>
                          <p><strong>Submitted:</strong> {new Date(appeal.created_at).toLocaleDateString()}</p>
                          <p><strong>Reason:</strong> {appeal.reason}</p>
                          {appeal.reviewed_at && (
                            <p><strong>Reviewed:</strong> {new Date(appeal.reviewed_at).toLocaleDateString()}</p>
                          )}
                        </div>
                      </AlertDescription>
                    </div>
                  </div>
                </Alert>
              ))}
            </div>
          )}

          {appeals.length === 0 && !isLoadingAppeals && searchPassengerId && (
            <Alert className="mt-4">
              <AlertDescription>
                No appeals found for this passenger ID
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AppealPage;
