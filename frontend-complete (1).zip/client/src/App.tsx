import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { ThemeProvider } from "@/contexts/ThemeContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import AdminProtectedRoute from "@/components/AdminProtectedRoute";
import Layout from "@/components/Layout";
import Login from "./pages/Login";
import AdminLogin from "./pages/AdminLogin";
import AdminSetup from "./pages/AdminSetup";
import AdminPanel from "./pages/AdminPanel";
import Dashboard from "./pages/Dashboard";
import Scan from "./pages/Scan";
import Incident from "./pages/Incident";
import Settings from "./pages/Settings";
import CreatePassenger from "./pages/CreatePassenger";
import Appeal from "./pages/Appeal";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Layout>
              <Routes>
                <Route path="/" element={<Navigate to="/login" replace />} />
                <Route path="/login" element={<Login />} />
                <Route 
                  path="/admin-login" 
                  element={<AdminLogin />} 
                />
                <Route 
                  path="/admin-setup" 
                  element={<AdminSetup />} 
                />
                <Route 
                  path="/admin-panel" 
                  element={
                    <AdminProtectedRoute>
                      <AdminPanel />
                    </AdminProtectedRoute>
                  } 
                />
                <Route 
                  path="/dashboard" 
                  element={
                    <ProtectedRoute>
                      <Dashboard />
                    </ProtectedRoute>
                  } 
                />
                <Route 
                  path="/scan" 
                  element={
                    <ProtectedRoute>
                      <Scan />
                    </ProtectedRoute>
                  } 
                />
                <Route 
                  path="/incident" 
                  element={
                    <ProtectedRoute>
                      <Incident />
                    </ProtectedRoute>
                  } 
                />
                <Route 
                  path="/settings" 
                  element={
                    <ProtectedRoute>
                      <Settings />
                    </ProtectedRoute>
                  } 
                />
                <Route 
                  path="/passenger/new" 
                  element={
                    <ProtectedRoute>
                      <CreatePassenger />
                    </ProtectedRoute>
                  } 
                />
                <Route 
                  path="/appeal" 
                  element={
                    <ProtectedRoute>
                      <Appeal />
                    </ProtectedRoute>
                  } 
                />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </Layout>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
